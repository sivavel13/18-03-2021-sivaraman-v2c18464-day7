package day7;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;


public class ComparatorExample {
	
	public static void main(String[] args) {
		
		ArrayList<Company>list=new ArrayList<Company>();
		list.add(new Company(2, "VeeTech", "VeeInnovative", 1986));
		list.add(new Company(10, "Google", "Chorome", 1997));
		list.add(new Company(7, "Amazon", "Keywords", 1987));
		
		System.out.println("Sorting By Names:");
		Collections.sort(list,new CompanyName());
		for (Company company : list) {
			System.out.println(company.comId+" "+company.CompanyName+" "+company.ProjectName+" "+company.years);
		}
		
		System.out.println("Sorting By Years:");
		Collections.sort(list,new YearsComparator());
		for (Company company : list) {
			System.out.println(company.comId+" "+company.CompanyName+" "+company.ProjectName+" "+company.years);
		}
	}
}

//Declare the datatypes and variable 
class Company {

	int comId;
	String CompanyName;
	String ProjectName;
	int years;
	public Company(int comId, String companyName, String projectName, int years) {
		super();
		this.comId = comId;
		CompanyName = companyName;
		ProjectName = projectName;
		this.years = years;
	}
	
}

class CompanyName implements Comparator { 


//using CompareTO single 
public int compare(Object a1, Object a2) {
	Company com=(Company) a1;
	Company com1=(Company) a2;
	
	return com.CompanyName.compareTo(com1.CompanyName);
}
}

//years comparision
class YearsComparator implements Comparator<Company> {	

	public int compare(Company Obj1, Company Obj2) {
		Company com=(Company) Obj1;
		Company com1=(Company) Obj2;
		if (com.years==com1.years) 
		{
			return 0;	
		}
		else if(com.years>com1.years) 
		{
			return 1;
		}
		else
		{
			return -1;
				
		}
		
	}

}